#!/bin/python
#filename: backup.py

import sys
import time
import commands

def fm(s):
	if(s < 10):
		return '0%d' % s
	else:
		return '%d' % s
	#return s < 10 ? '0%d' % s : s

argv = sys.argv
if len(argv) < 3:
	print "usage: %s <backup name> <filename1>[ <filename2> ...]" % argv[0]
	exit(1)

date = time.localtime()
year = date.tm_year
month = fm(date.tm_mon) 
day = fm(date.tm_mday) 
hour = fm(date.tm_hour) 
min = fm(date.tm_min)
filename = "%s-%s%s%s-%s%s.tar.gz" % (argv[1], year, month, day, hour, min) 

cmd = 'tar -czvf %s ' % filename
for i in xrange(2, len(argv)):
	cmd += '%s ' % argv[i] 

status, output = commands.getstatusoutput(cmd)

#print status

print output
if not status:
	print "backup successful..."
else:
	commands.getstatusoutput("rm %s" % filename)
	print "backup failed..."
