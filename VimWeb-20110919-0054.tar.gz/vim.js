(function() {
	var document = window.document;
	var $ = window.jQuery;
	var $document = $(document);
	var $body = $("body");
	var $vimscr = undefined;
	var $cursor = undefined;
	var cursorTimer = undefined;

	var valContext = {
		'vimscr': {
			name: 'vim',
			selector: '#vim'
		},
		'document': {
			name: 'document',
			selector: 'document'
		},
		'body': {
			name: 'body',
			selector: 'body'
		}
	};

	var logger = function(msg) {
		console.log(msg);
	};

	var MODE = {
		NORMAL: 0,
		INSERT: 1,
		VISUAL: 2,
		SELECT: 3,
		COMMAND: 4
	};

	var keyMap = {
		'27': 'esc',
		'45': 'insert',
		'8': 'back',
		'36': 'home',
		'35': 'end',
		'9': 'tab',
		'46': 'del',
		'33': 'pageup',
		'34': 'pagedown',
		'20': 'caps',
		'16': 'shift',
		'17': 'ctrl',
		'18': 'alt',
		'91': 'win',
		'37': 'left',
		'38': 'up',
		'39': 'right',
		'40': 'down'
	};

	var cursor = {};

	var terminal = {
		_cols: 80,
		_rows: 25,
		_base: 0,
		scrollDown: function() {
			if(this._base != 0){
				this._base += 1;
			}
		},
		scrollUp: function() {
			if(this._base != 0) {
				this._base -= 1;
			}
		},
		scroll: function(x) {
			
		},
		lineHead: function() {
			return 0;
		},
		lineTail: function() {
			var line = editor._context.file[this._base];
			return line.length;
		},
		colHead: function() {
			return 0;
		},
		colTail: function() {
			return editor._context.file.length;
		}
	};

	cursor = {
		x: 0,
		y: 0,
		width: -1,
		height: -1,
		active: true,
		interval: 400,
		toString: function() {
			return 'cursor: (' + this.x + ',' + this.y + ')';
		},
		_location: function() {
			return {
				x: this.x,
				y: this.y
			};
		},
		_log: function() {
			logger(this.toString());
		},
		_up: function(v) {
			this.y -= v;
		},
		_down: function(v) {
			this.y += v;
		},
		_left: function(v) {
			this.x -= v;
		},
		_right: function(v) {
			this.x += v;
		},
		_move: function(x, w) {
			if(!w || w == 'r') {
				this.x += x;
			}else if(w == 'l'){
				this.y += x;
			}else{
				throw exception("error arguments...");
			}
		},
		_head: function(v) {
			this.x = 0;
			this.y = 0;
		},
		_tail: function(v) {
			this.x = terminal._cols - 1;
			this.y = terminal._rows - 1;
		},
		_linehead: function(v) {
			this.x = terminal.lineHead();
		},
		_linetail: function(v) {
			this.x = terminal.lineTail();
		},

		up: function() {
			if (this.y != 0) {
//				this._up(1);
				this._move(-1, 'l');
			}
			this._log();
		},
		down: function() {
			if (this.y < terminal._rows - 1) {
//				this._down(1);
				this._move(1, 'l');
			}
			this._log();
		},
		left: function() {
			if (this.x != 0) {
//				this._left(1);
				this._move(-1, 'r');
			}
			this._log();
		},
		right: function() {
			if (this.x < terminal._cols - 1) {
//				this._right(1);
				this._move(1, 'r');
			}
			this._log();
		},
		head: function() {
			this._head();
			this._log();
		},
		tail: function() {
			this._tail();
			this._log();
		},
		linehead: function() {
			this._linehead();
			this._log();
		},
		linetail: function() {
			this._linetail();
			this.log();
		}
	};

	var normalCmdMap = {
		log: function(cmd) {
			logger('normal:command:\'' + cmd + '\'');
		},
		'h': function() {
			cursor.left();
			editor._redraw();
			this.log('h');
		},
		'left': function() {
			this['h']();
		},

		'j': function() {
			cursor.down();
			editor._redraw();
			this.log('j');
		},
		'down': function() {
			this['j']();
		},

		'k': function() {
			cursor.up();
			editor._redraw();
			this.log('k');
		},
		'up': function() {
			this['k']();
		},

		'l': function() {
			cursor.right();
			editor._redraw();
			this.log('l');
		},
		'right': function() {
			this['l']();
		},
		'i': function() {
		},
		'I': function() {
		},
		'a': function() {
		},
		'A': function() {
		},
		'o': function() {
		},
		'O': function() {
		},
		'esc': function() {
		}
	};

	var insertCmdMap = {
		'esc': function() {
		}
	};

	var visualCmpMap = {
		'esc': function() {
		}
	};

	var selectCmdMap = {
		'esc': function() {
		}
	};

	var commandCmdMap = {
		'esc': function() {
		}
	};

	var editor = {
		/*
		 * 默认参数
		 */
		_default: {
			input: {
				name: 'input',
				selector: '#input'
			}
		},
		_args: {},
		/*
		 * 变量声明
		 */
		_context: {
			file: [],
			currentRow: 0,
			cmd: {
				queue: {
					normal: [],
					command: [],
					visual: [],
					tmp: []
				},
				current: "",
				times: 0,
				ctimes: '0',
				ttimes: 0
			},
			font: {
				'font-family': 'monospace',
				'font-size': '100%'
			},
			color: {
				'background-color': 'rgba(255,255,255,255)',
				'color': 'rgba(0,0,0,255)'
			},
			event: null,
			presslock: false
		},
		_cmdmap: {},
		_mode: MODE.NORMAL,

		/*
		 * 函数声明和定义
		 */
		init: function() {

			// 初始化参数
			this._args = editor._default;
			// 初始化上下文
			this._initContext();
			// 绑定模式命令的执行函数
			this._cmdMapBind();
			// 读取需要处理的文件
			this._readFile();
			// 初始化界面
			this._initDraw();
		},
		_initCursor: function() {
			cursor.width = $cursor[0].offsetWidth;
			cursor.height = $cursor[0].offsetHeight;
		},
		_initContext: function() {
			
			// 初始化全局变量
			terminal._base = 0;
		},
		/*
		 * 读取原有的文本
		 */
		_readFile: function() {
			var input = document.getElementById(editor._args.input.name);
			var inputValue = input.value;
			var inputValueList = inputValue.split('\n');
			editor._context.file = [];
			var i;
			for (i = 0; i < inputValueList.length; ++i) {
				editor._context.file[i] = inputValueList[i];
			}
			logger(editor._context.file);
		},
		_cmdMapBind: function() {
			this._cmdmap[MODE.NORMAL + ''] = normalCmdMap;
			this._cmdmap[MODE.INSERT + ''] = insertCmdMap;
			this._cmdmap[MODE.VISUAL + ''] = visualCmpMap;
			this._cmdmap[MODE.SELECT + ''] = selectCmdMap;
			this._cmdmap[MODE.COMMAND + ''] = commandCmdMap;
		},
		_initDraw: function() {
			// 隐藏原来的节点
			var i;
			for (i = document.body.firstChild; i; i = i.nextSibling) {
				if (i.tagName) {
					i._backupStyleDisplay = i.style.display;
					i._orgin = true;
					i.style.display = 'none';
				}
			}

			editor._draw();
			editor._initCursor();

		},
		_drawContent: function() {
			if ($vimscr) {
				$vimscr.remove();
			}

			$vimscr = $("<div></div>").attr("id", valContext.vimscr.name)
					.appendTo("body");

			var i;
			var rows = terminal._rows;
			for (i = 0; i < rows; i++) {
				var cr = editor._context.currentRow + i + terminal._base;
				var s = "";
				var currentFileString = editor._context.file[cr];
				if (i == rows - 1) {
					s += "current mode";
				} else if (currentFileString == undefined) {
					s += '~';
				} else if (currentFileString) {
					s += currentFileString;
				} else {
					s = '<br>';
				}
				$("<pre></pre>").css({
					'margin': '0px',
					'margin-bottom': '1px',
					'padding': '0px',
					'font-family': 'monospace',
					'font-size': '100%'
				}).html(s).appendTo(valContext.vimscr.selector);
			}
		},
		_drawCursor: function() {
			// var _cursor = editor._context.cursor;
			var _cursor = cursor;
			var color = {
				'true': editor._context.color['background-color'],
				'false': editor._context.color['color']
			};
			
			var left = $vimscr.offset().left + _cursor.x * (_cursor.width);
			var top = $vimscr.offset().top + _cursor.y * (_cursor.height + 1); // margin-bottom = 1px
			
			var s = '&nbsp;';
			
			var line = null;
			
			try {
				line = editor._context.file[_cursor.y];
				if(_cursor.x < line.length) {
					s = line[_cursor.x];
				}else{
					throw exception();
				}
			} catch (e) {
				s = '&nbsp;';
			}

//			if (!s) {
//				s = '&nbsp;';
//			}

			if ($cursor) {
				window.clearInterval(cursorTimer);
				$cursor.css({
					'left': left,
					'top': top,
					'background-color': color[false],
					'color': color[true]
				}).html(s).appendTo(valContext.vimscr.selector);
			} else {
				$cursor = $('<div></div>').html(s).attr('id', 'cursor').css({
					'margin': '0px',
					'margin-bottom': '1px',
					'padding': '0px',
					'position': 'absolute',
					'background-color': color[false],
					'color': color[true],
					'left': left,
					'top': top,
					'font-family': 'monospace',
					'font-size': '100%'
				}).appendTo(valContext.vimscr.selector);
			}
			_cursor.active = true;
			cursorTimer = setInterval(function() {
				$cursor.css({
					'background-color': color[_cursor.active],
					'color': color[!_cursor.active]
				});
				_cursor.active = !_cursor.active;
			}, _cursor.interval);
		},
		_draw: function() {
			editor._drawContent();
			editor._drawCursor();
		},
		_redraw: function() {
			editor._draw();
		},
		/*
		 * _filterTemplate 过滤器模板 _fr 过滤条件函数 _frp 过滤参数 _fe 执行函数 _fep 执行函数参数 _msg
		 * 记录信息
		 */
		_filterTemplate: function(_fr, _frp, _fe, _fep, _msg, that) {
			if (_fr(_frp)) {
				_fe(_fep);
				if (_msg != undefined) {
					logger(_msg);
				}
				// that._context.event = window.event;
				return true;
			}
			return false;
		},
		// 命令处理功能函数
		_comandConctrl: function() {
			var cmd = editor._context.cmd.current;
			editor._context.cmd.current = null;
			try {
				editor._cmdmap[this._mode][cmd]();
			} catch (e) {
				logger(e.toString());
			}
		},
		/*
		 * 次数处理函数
		 */
		_keyTimes: function(e) {
			var key = e.keyCode;
			var keyChar = String.fromCharCode(key);
			if (editor._context.cmd.ttimes) {
				editor._context.cmd.ctimes += keyChar;
				editor._context.cmd.ttimes = parseInt(editor._context.cmd.ctimes);
			} else {
				editor._context.cmd.ttimes = key - 48;
				editor._context.cmd.ctimes = keyChar;
			}
		},
		// 获取执行次数
		_keyGetTimes: function() {
			if (editor._context.cmd.ttimes) {
				editor._context.cmd.times = editor._context.cmd.ttimes;
				editor._context.cmd.ttimes = 0;
				editor._context.cmd.ctimes = '0';
			}
			return editor._context.cmd.times;
		},
		/*
		 * 按键映射命令函数 参数: e 按键事件
		 */
		_keyToCmd: function(e) {
			if (!e) {
				e = window.event;
			}

			var key = e.which || e.keyCode;
			var keyChar = String.fromCharCode(key);

			editor._context.cmd.current = keyChar;

			// var key = e.keyCode;
			// var keyChar = String.fromCharCode(key);
			// if(!this._keyToCmd && 48 <= key && key <= 57) {
			// this._keyTimes(e);
			// return false;
			// }
			//			
			// var times = this._keyGetTimes();
			// logger(times);

			// var mod = editor._mode;
			// switch(mod) {
			// case MODE.NORMAL:
			// break;
			// case MODE.INSERT:
			// break;
			// case MODE.VISUAL:
			// break;
			// case MODE.SELECT:
			// break;
			// case MODE.COMMAND:
			// break;
			// default:
			// logger("error mode!");
			// break;
			// }
		},
		// keydown事件过滤器,主要用于屏蔽浏览器快捷键
		_keydownFilter: function(e) { // 按键过滤器,屏蔽浏览器默认按键
			var key = e.which;
			var filterTemplate = this._filterTemplate;

			// F1~F12 按键屏蔽
			filterTemplate(function(e) {
				var v = e.which;
				return 112 <= v && v <= 123 ? true : false;
			}, e, function(e) {
				editor._keyShield(e);
				// 跳过 keypress 事件
				editor._context.presslock = true;
			}, e, "屏蔽F" + (key - 111) + "按键", this);

			// 屏蔽 C-r 快捷键
			filterTemplate(function(e) {
				return e.ctrlKey && e.keyCode == 82 ? true : false;
			}, e, function(e) {
				editor._keyShield(e);
				// 跳过 keypress 事件
				editor._context.presslock = true;
			}, e, "屏蔽 C-r 快捷键", this);

			// 屏蔽 C-w 快捷键
			filterTemplate(function(e) {
				return e.ctrlKey && e.keyCode == 87 ? true : false;
			}, e, function(e) {
				editor._keyShield(e);
				// 跳过 keypress 事件
				editor._context.presslock = true;
			}, e, "屏蔽 C-w 快捷键", this);

			// 屏蔽 C-n 快捷键
			filterTemplate(function(e) {
				var key = e.keyCode;
				return e.ctrlKey && key == 78 ? true : false;
			}, e, function(e) {
				editor._keyShield(e);
				// 跳过 keypress 事件
				editor._context.presslock = true;
			}, e, "屏蔽 C-n 快捷键", this);

			// 重聚焦到Document对象
			filterTemplate(function(e) {
				return e.which == 9 ? true : false;
			}, e, function(e) {
				// 将焦点设置为document
				$document.focus();
				$document.select();
				// 跳过 keypress 事件
				editor._context.presslock = true;
			}, e, "重聚焦document对象", this);

			// 过滤成功,跳过keypress事件执行命令处理函数
			if (editor._context.presslock) {
				// editor._comandConctrl(e);
				editor._keyToCmd(e);
				e.cancelBubble = true;
				return false;
			} else {
				e.cancelBubble = false;
				return true;
			}
		},
		// 屏蔽按键功能函数
		_keyShield: function(e) {
			// 取消事件的默认动作
			if (e.preventDefault) {
				e.preventDefault();
			}
			// 不再派发事件
			if (e.stopPropagation) {
				e.stopPropagation();
			}
		},
		// 将按键转变成命令,交由命令处理函数执行
		_keypress: function(e) {
			// 如果keydown事件已经处理按键事件,则跳过keypress事件
			if (editor._context.presslock) {
				editor._context.presslock = false;
				return;
			}

			var __fn = '_keypress';
			var key = e.keyCode;
			var keyChar = String.fromCharCode(key);
			logger(__fn + ', key: ' + key + ', keyChar: ' + keyChar);
			// this._context.cmd.current = keyChar;
			// this._context.event = e;
			editor._keyToCmd(e);
			editor._comandConctrl(e);
			// this._changemode();
		},
		// 将按键转变成命令,交由命令处理函数执行
		_keydown: function(e) {
			var __fn = '_keydown';
			logger(__fn + ": " + e.which);
			// var key = e.keyCode;
			// this._context.cmd.current = keyMap[key + ''];
			var ret = this._keydownFilter(e);
			this._comandConctrl();
			return ret;
		}
	// _changemode: function() {
	// var cmd = this._context.cmd.current;
	//
	// var changemodelog = function(mode, cmd) {
	// logger("mode change to " + mode);
	// logger("change by cmd: " + cmd);
	// };
	//
	// switch (editor._mode) {
	// case MODE.NORMAL:
	// logger("normal mode");
	// if (cmd == 'a' || cmd == 'A' || cmd == 'i' || cmd == 'I'
	// || cmd == 'o' || cmd == 'O') {
	// editor._mode = MODE.INSERT;
	// changemodelog("INSERT", cmd);
	// }
	// break;
	// case MODE.INSERT:
	// logger("insert mode");
	// // if (cmd == 'esc') {
	// // editor._mode = MODE.NORMAL;
	// // changemodelog("NORMAL", cmd);
	// // }
	// break;
	// case MODE.VISUAL:
	// logger("visual mode");
	// break;
	// case MODE.SELECT:
	// logger("select mode");
	// break;
	// case MODE.COMMAND:
	// logger("command mode");
	// break;
	// default:
	// logger("error mode!");
	// break;
	// }
	// }
	};
	window.vim = function() {
		editor.init();
		$document.keydown(function(e) {
			editor._keydown(e);
		});
		$document.keypress(function(e) {
			editor._keypress(e);
			// switch(editor.mode) {
			// case MODE.NORMAL:
			// logger("normal mode");
			// break;
			// case MODE.INSERT:"
			// logger("insert mode");
			// break;
			// case MODE.VISUAL:
			// logger("visual mode");
			// break;
			// case MODE.SELECT:
			// logger("select mode");
			// break;
			// case MODE.COMMAND:
			// logger("command mode");
			// break;
			// default:
			// logger("error mode!");
			// break;
			// }
		});
	};
})();
