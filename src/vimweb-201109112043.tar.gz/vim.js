(function() {
var document = window.document;
var $ = window.jQuery;

var MODE = {};
MODE.NORMAL	= 0;
MODE.INSERT	= 1;
MODE.VISUAL	= 2;
MODE.SELECT	= 3;
MODE.COMMAND	= 4;

var logger = function(msg) {
	console.log(msg);
};
var editor = {
	mode: MODE.NORMAL,
	changeMode: function(cmd) {

	},
};


window.vim = function() {
	$(document).keydown(function(e) {
		switch(editor.mode) {
		case MODE.NORMAL:
			logger("normal mode");
			break;
		case MODE.INSERT:
			logger("insert mode");
			break;
		case MODE.VISUAL:
			logger("visual mode");
			break;
		case MODE.SELECT:
			logger("select mode");
			break;
		case MODE.COMMAND:
			logger("command mode");
			break;
		default:
			logger("error mode!");
			break;
		}
		return false;
	});
};


})();
